#include <iostream>

int main(int argc, char* ARGV[])
{
		std::cout << "Hello, Kevin!\n";
	return 0;
}
